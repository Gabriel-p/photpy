Para compilar:


g77 -c (soubroutine).f (subroutine).o

g77 -o (ejecutable) (programa).f (subroutine1).o (subroutine2).o .....
